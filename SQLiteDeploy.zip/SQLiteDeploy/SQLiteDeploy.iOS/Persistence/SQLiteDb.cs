﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using SQLite;
using SQLiteDeploy.iOS.Persistence;
using SQLiteDeploy.Persistence;
using UIKit;
using Xamarin.Forms;

[assembly: Dependency(typeof(SQLiteDb))]
namespace SQLiteDeploy.iOS.Persistence
{
    public class SQLiteDb : ISQLiteDb
    {

        public SQLiteAsyncConnection GetConnection()
        {
            var documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
            var path = System.IO.Path.Combine(documentsPath, "SQLite.db3");    

            return new SQLiteAsyncConnection(path);
        }

    }

}