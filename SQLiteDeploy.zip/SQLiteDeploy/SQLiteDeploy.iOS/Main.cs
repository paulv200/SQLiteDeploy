﻿using System;
using System.Collections.Generic;
using System.Linq;

using Foundation;
using UIKit;

namespace SQLiteDeploy.iOS
{
    public class Application
    {
        // This is the main entry point of the application.
        static void Main(string[] args)
        {

            //Copy over database
            var SQLiteAsset = "SQLite.db3";   //database name
            var documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
            var dbDestinationFolder = System.IO.Path.Combine(documentsPath, SQLiteAsset);
            FileAccessHelper.CopyDatabaseIfNotExists(dbDestinationFolder, SQLiteAsset);    

            // if you want to use a different Application Delegate class from "AppDelegate"
            // you can specify it here.
            UIApplication.Main(args, null, "AppDelegate");
        }
    }
}
