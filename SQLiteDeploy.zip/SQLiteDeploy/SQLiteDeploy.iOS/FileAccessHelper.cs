﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;

namespace SQLiteDeploy.iOS
{
    public class FileAccessHelper
    {

        //-------------------------------------------------------------------------
        /// <summary>
        /// This copies the database over if it does not exist on the Andriod device
        /// If the file does not exist in dbPath, then copy it from SQLiteAsset location
        /// </summary>
        /// <param name="dbDestination">The path of the database on the iOS device</param>
        /// <param name="SQLiteAsset">The database name in the installation folder</param>
        public static void CopyDatabaseIfNotExists(string dbDestination, string SQLiteAsset)
        {

            //https://forums.xamarin.com/discussion/106687/copying-sqlite-db-from-bundle-to-library
            if (!File.Exists(dbDestination))  //If file does not exist, then copy file to it from the resources folder located at NSBundle.MainBundle.PathForResource                
            {
                var ext = Path.GetExtension(SQLiteAsset);
                var name = Path.GetFileNameWithoutExtension(SQLiteAsset);
                var dbSource = NSBundle.MainBundle.PathForResource(name, ext);

                //check if database exists at source first.
                if (File.Exists(dbSource))
                {
                    File.Copy(dbSource, dbDestination, true);
                }
            }
        }
        //-------------------------------------------------------------------------

    }
}