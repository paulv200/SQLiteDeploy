﻿using SQLite;
using SQLiteDeploy.Models;
using SQLiteDeploy.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SQLiteDeploy.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Listing : ContentPage
	{

        private SQLiteAsyncConnection _connection;
        private List<Recipe> _sortedRecipeList;

        public Listing ()
		{
			InitializeComponent ();

            //----------------------------------
            //SQLite
            _connection = DependencyService.Get<ISQLiteDb>().GetConnection();
            //----------------------------------
        }

        protected override async void OnAppearing()
        {
            await RefreshData();
            base.OnAppearing();
        }

        protected async Task RefreshData()
        {
            try
            {

                var recipeList = await _connection.Table<Recipe>().ToListAsync();

                var sortedRecipeList = from rl in recipeList
                                       orderby rl.Description
                                       select rl;

                _sortedRecipeList = sortedRecipeList.ToList();

                ListRecipeView.ItemsSource = _sortedRecipeList;

            }
            catch
            {
                await DisplayAlert("Alert", "There was an error in retrieving the list.  Please try again", "OK");
            }
        }

    }
}