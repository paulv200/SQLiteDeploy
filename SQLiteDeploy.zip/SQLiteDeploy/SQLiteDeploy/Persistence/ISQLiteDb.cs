﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace SQLiteDeploy.Persistence
{
    public interface ISQLiteDb
    {
        SQLiteAsyncConnection GetConnection();
    }
}
