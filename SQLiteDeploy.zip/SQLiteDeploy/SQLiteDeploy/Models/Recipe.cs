﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace SQLiteDeploy.Models
{
    public class Recipe
    {

        //The incremented record id
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }

        //The decription of the recipe
        [MaxLength(255)]
        public string Description { get; set; }

    }

}
